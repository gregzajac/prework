from library_app import create_app

application = create_app('production')
